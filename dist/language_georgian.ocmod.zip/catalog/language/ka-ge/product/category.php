<?php
// Text
$_['text_refine']      = 'ქვე კატეგორიები';
$_['text_product']     = 'პროდუქტები';
$_['text_no_results']  = 'ამ კატეგორიაში ჩამოსათვლელი პროდუქტები არ არის.';
$_['text_compare']     = 'შეადარე (%s)';
$_['text_sort']        = 'დალაგება:';
$_['text_default']     = 'გულისხმობით';
$_['text_name_asc']    = 'სახელით (ა - ჰ)';
$_['text_name_desc']   = 'სახელით (ჰ - ა)';
$_['text_price_asc']   = 'ფასით (დაბლიდან &gt; მაღლისკენ)';
$_['text_price_desc']  = 'ფასით (მაღლიდან &gt; დაბლისკენ)';
$_['text_rating_asc']  = 'რეიტინგით (დაბალი)';
$_['text_rating_desc'] = 'რეიტინგით (მაღალი)';
$_['text_model_asc']   = 'მოდელი (ა - ჰ)';
$_['text_model_desc']  = 'მოდელი (ჰ - ა)';
$_['text_limit']       = 'მიჩვენე:';
