<?php
// Text
$_['text_success']           = 'Success: You have modified subscriptions!';

// Error
$_['error_customer']         = 'Warning: Customer details required!';
$_['error_payment_address']  = 'Warning: Payment address required!';
$_['error_payment_method']   = 'Warning: Payment method required!';
$_['error_shipping_address'] = 'Warning: Shipping address required!';
$_['error_shipping_method']  = 'Warning: Shipping method required!';
$_['error_product']          = 'Warning: Products required!';
$_['error_stock']            = 'Warning: Products marked with *** are not available in the desired quantity or not in stock!';
$_['error_minimum']          = 'Warning: Minimum order amount for %s is %s!';
$_['error_call']             = 'API call not found';
