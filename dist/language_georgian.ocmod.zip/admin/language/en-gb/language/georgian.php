<?php
// Heading
$_['heading_title']    = 'ქართული Language';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified ქართული language!';
$_['text_edit']        = 'Edit ქართული Language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify ქართული language!';
