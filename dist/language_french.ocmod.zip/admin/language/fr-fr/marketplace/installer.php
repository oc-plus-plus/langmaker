<?php
// Heading
$_['heading_title']          = 'Installateur d\'extensions';

// Text
$_['text_upload']            = 'Succès: l\'extension a été téléchargée!';
$_['text_success']           = 'Succès: Vous avez modifié les extensions!';
$_['text_progress']          = 'Progression de l\'installation';
$_['text_installed']         = 'Extensions installées';
$_['text_info']              = 'Information sur les extensions';
$_['text_install']           = 'Installation des fichiers à partir de %s envers %s de %s';
/* LM ADDED */ $_['text_vendor']            = 'Refresh vendor files';

// Column
$_['column_image']           = 'Image';
$_['column_name']            = 'Nom de l\'extension';
$_['column_version']         = 'Version';
$_['column_date_added']      = 'Date d\'ajout';
$_['column_action']          = 'Action';

// Entry
$_['entry_progress']         = 'Progression';
$_['entry_name']             = 'Nom de l\'extension';
$_['entry_description']      = 'Description';
$_['entry_code']             = 'Code';

// Error
$_['error_permission']       = 'Attention: Vous n\'avez pas la permission de modifier les extensions!';
$_['error_install']          = 'Attention: Impossible de trouver install.json!';
$_['error_default']          = 'l\'extension par défaut ne peut pas être désinstallée ou supprimée!';
$_['error_extension']        = 'l\'extension installée est introuvable!';
$_['error_installed']        = 'Extension déjà installée!';
$_['error_uninstall']        = 'Il y a %s extensions qui doivent être désinstallées avant que cette extension puisse être supprimée en toute sécurité!';
$_['error_name']             = 'Le nom doit comporter entre 3 et 128 caractères!';
$_['error_version']          = 'La version doit comporter entre 3 et 128 caractères!';
$_['error_author']           = 'l\'auteur doit comporter entre 3 et 128 caractères!';
$_['error_filename']         = 'Le nom du fichier doit comporter entre 3 et 128 caractères!';
$_['error_file']             = 'Le fichier d\'installation %s est introuvable!';
$_['error_file_exists']      = 'Le fichier existe déjà!';
$_['error_file_type']        = 'Type de fichier invalide!';
$_['error_directory']        = 'Le répertoire d\'installation %s est introuvable!';
$_['error_directory_exists'] = 'Le chemin %s existe déjà!';
$_['error_unzip']            = 'Impossible d\'ouvrir le fichier .zip!';
$_['error_upload']           = 'Le fichier n\'a pu être téléchargé!';
$_['error_unknown']          = 'Une erreur inconnue s’est produite!';

// Zip errors
$_['zip_error_exists']       = 'Le fichier existe déjà!';
$_['zip_error_incons']       = 'Archive zip incohérente!';
$_['zip_error_inval']        = 'Argument invalide!';
$_['zip_error_memory']       = 'Échec de l’allocation de mémoire!';
$_['zip_error_noent']        = 'Aucun fichier trouvé!';
$_['zip_error_nozip']        = 'Ce n’est pas une archive zip!';
$_['zip_error_open']         = 'Impossible d’ouvrir le fichier!';
$_['zip_error_read']         = 'Erreur de lecture!';
$_['zip_error_seek']         = 'Erreur de positionnement!';
