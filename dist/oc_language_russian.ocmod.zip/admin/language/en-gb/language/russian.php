<?php
// Heading
$_['heading_title']    = 'Русский Language';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Русский language!';
$_['text_edit']        = 'Edit Русский Language';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Русский language!';
