<?php
// Locale
$_['code']                  = 'ru';
$_['direction']             = 'ltr';
$_['date_format_short']     = 'd.m.Y';
$_['date_format_long']      = 'l, d F Y';
$_['time_format']           = 'H:i:s';
$_['datetime_format']       = 'd/m/Y H:i:s';
$_['decimal_point']         = '.';
$_['thousand_point']        = '';

// Text
$_['text_home']             = '<i class="fas fa-home"></i>';
$_['text_yes']              = 'Да';
$_['text_no']               = 'Нет';
$_['text_none']             = ' --- Не выбрано --- ';
$_['text_select']           = ' --- Выберите --- ';
$_['text_all_zones']        = 'Все зоны';
$_['text_pagination']       = 'Показано с %d по %d из %d (всего %d страниц)';
$_['text_loading']          = 'Загрузка...';
$_['text_no_results']       = 'Нет данных!';
$_['text_just_now']         = 'сейчас';
$_['text_seconds_ago']      = '%s секунд назад';
$_['text_minute_ago']       = '%s минута назад';
$_['text_minutes_ago']      = '%s минуты назад';
$_['text_hour_ago']         = '%s час назад';
$_['text_hours_ago']        = '%s часов назад';
$_['text_day_ago']          = '%s день назад';
$_['text_days_ago']         = '%s дней назад';
$_['text_week_ago']         = '%s неделя назад';
$_['text_weeks_ago']        = '%s недель назад';
$_['text_month_ago']        = '%s месяц назад';
$_['text_months_ago']       = '%s месяцев назад';
$_['text_year_ago']         = '%s год назад';
$_['text_years_ago']        = '%s года назад';

// Buttons
$_['button_address_add']    = 'Добавить адрес';
$_['button_back']           = 'Назад';
$_['button_continue']       = 'Продолжить';
$_['button_cart']           = 'Купить';
$_['button_cancel']         = 'Отмена';
$_['button_compare']        = 'В сравнение';
$_['button_wishlist']       = 'В закладки';
$_['button_checkout']       = 'Оформление заказа';
$_['button_confirm']        = 'Подтверждение заказа';
$_['button_coupon']         = 'Применение купона';
$_['button_delete']         = 'Удалить';
$_['button_download']       = 'Скачать';
$_['button_edit']           = 'Редактировать';
$_['button_filter']         = 'Поиск';
$_['button_new_address']    = 'Новый адрес';
$_['button_change_address'] = 'Изменить адрес';
$_['button_reviews']        = 'Отзывы';
$_['button_write']          = 'Написать отзыв';
$_['button_login']          = 'Войти';
$_['button_update']         = 'Обновить';
$_['button_remove']         = 'Удалить';
$_['button_reorder']        = 'Дополнительный заказ';
$_['button_return']         = 'Вернуть';
$_['button_shopping']       = 'Продолжить покупки';
$_['button_search']         = 'Поиск';
$_['button_shipping']       = 'Применить Доставку';
$_['button_submit']         = 'Отправить';
$_['button_guest']          = 'Оформление заказа без регистрации';
$_['button_view']           = 'Просмотр';
$_['button_voucher']        = 'Применить подарочный сертификат';
$_['button_upload']         = 'Загрузить файл';
$_['button_reward']         = 'Применить бонусные баллы';
$_['button_quote']          = 'Узнать цены';
$_['button_list']           = 'Список';
$_['button_grid']           = 'Сетка';
$_['button_map']            = 'Посмотреть карту';

// Error
$_['error_exception']       = 'Ошибка кода(%s): %s в %s на строке %s';
$_['error_upload_1']        = 'Предупреждение: Размер загружаемого файла превышает значение upload_max_filesize в php.ini!';
$_['error_upload_2']        = 'Предупреждение: Загруженный файл превышает MAX_FILE_SIZE значение, которая была указана в настройках!';
$_['error_upload_3']        = 'Предупреждение: Загруженные файлы были загружены лишь частично!';
$_['error_upload_4']        = 'Предупреждение: Нет файлов для загрузки!';
$_['error_upload_6']        = 'Предупреждение: Отсутствует временная директория!';
$_['error_upload_7']        = 'Предупреждение: Ошибка записи!';
$_['error_upload_8']        = 'Предупреждение: Запрещено загружать файл с данным расширением!';
$_['error_upload_999']      = 'Предупреждение: Неизвестная ошибка!';
$_['error_upload_size']     = 'Внимание: Загруженный файл превышает максимальный размер файла. Максимальный размер %s МБ !';
$_['error_curl']            = 'CURL: Ошибка кода(%s): %s';
$_['error_session']         = 'Внимание: Сеанс истек, пожалуйста, отправьте форму еще раз!';

// Когда нужен перевод скриптов, просто добавь код языка

// Datepicker
$_['datepicker']            = 'ru';
